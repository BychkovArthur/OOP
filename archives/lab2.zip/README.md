# Использование

### Собрать/пересобрать решение

```
make build labNum=<number of lab>
```

### Запустить решение

```
make run labNum=<number of lab>
```

### Запустить тесты

```
make test labNum=<number of lab>
```

### Удалить build
```
make clean labNum=<number of lab>
```